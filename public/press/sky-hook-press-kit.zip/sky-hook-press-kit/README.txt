SKY HOOK / PRESS KIT

Booking / press: skyhooknis@hotmail.com

Photos: JPEG. Logo: PNG. Biographies: UTF-8 text in Serbian and English.
Keep visible photographer credits when publishing.
For the current technical rider and stage plot, contact the band.

GDE PTICE LETE / LISTEN
youtube: https://www.youtube.com/watch?v=_UFk_n6rBOE&list=PLxDZmm8oF9f9AchKjFL9pGWJgLlb0R_v-
spotify: https://open.spotify.com/album/3xXuqUWaG0I2A5CjA1P9ep
appleMusic: https://music.apple.com/rs/album/gde-ptice-lete/1804065996
deezer: https://www.deezer.com/us/album/731979501
amazonMusic: https://music.amazon.com/albums/B0F29KYLVZ
anghami: https://play.anghami.com/album/1066421805?refer=linktree
tidal: https://tidal.com/album/425894161
bandcamp: https://skyhooknis.bandcamp.com/album/gde-ptice-lete
